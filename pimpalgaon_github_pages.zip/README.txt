GITHUB PAGES — मोबाइल मार्गदर्शक
1. या ZIP मधील index.html डाउनलोड करा.
2. GitHub → pimpalgaoncrc.github.io repository उघडा.
3. Add file → Upload files.
4. index.html निवडा.
5. Commit changes करा.
6. Settings → Pages → Deploy from a branch → main → / (root) → Save.
7. काही मिनिटांनी वेबसाइट:
   https://pimpalgaoncrc.github.io/

टीप: GitHub Pages वर PHP/MySQL चालत नाही. ही आवृत्ती static आहे. Login/Database नंतर स्वतंत्र free backend जोडून करता येईल.
